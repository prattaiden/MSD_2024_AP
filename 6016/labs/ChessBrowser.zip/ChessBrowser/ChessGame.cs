class ChessGame{
    public string event_;
    public string site_;
    public string round_;
    public string white_;
    public string black_;
    public int whiteElo_;
    public int blackElo_;
    public string result_;
    public string date_;
    public string moves_;

}